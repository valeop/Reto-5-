package Reto5;

public class Charizard extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Charizard(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        excepcion();
        return new Charizard(nombre, nivel, hp);
    }

    @Override
    public String gritar() {
        return "Charizard!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
