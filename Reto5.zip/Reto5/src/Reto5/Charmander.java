package Reto5;

public class Charmander extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Charmander(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        Charmeleon evo1 = new Charmeleon("Charmeleon", (byte) (nivel + 5), hp * 2);
        return evo1;
    }

    @Override
    public String gritar() {
        return "Charmander!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
