package Reto5;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Pokebola {

    public String tamaño;
    public Pokemon pokemon;
    public Object guardar;

    public Pokebola() {
    }

    public Pokebola(String tamaño, Pokemon pokemon) {
        this.tamaño = tamaño;
        this.pokemon = pokemon;
    }

    public Object guardarPokemon() {
        guardar = pokemon + " | Pokebola: " + tamaño;
        return guardar;
    }

    public void mostrarLista() {
        JOptionPane.showMessageDialog(null, "A continuación se mostrará una lista con los pokemones guardados", "ATENCIÓN", JOptionPane.INFORMATION_MESSAGE);
        System.out.println("\n                     LISTA ACTUALIZADA\n");
        for (int i = 0; i < Pokemon.lista.size(); i++) {
            System.out.println(Pokemon.lista.get(i));
        }
        System.out.println("------------------------------------------------------------");
    }

    @Override
    public String toString() {
        return "" + Pokemon.lista + pokemon + tamaño;
    }
}
