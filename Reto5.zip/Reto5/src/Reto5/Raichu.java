package Reto5;

public class Raichu extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Raichu(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        excepcion();
        return new Raichu("Raichu", nivel, hp);
    }

    @Override
    public String gritar() {
        return "Raichu!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }
}
