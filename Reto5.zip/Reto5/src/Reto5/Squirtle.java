package Reto5;

public class Squirtle extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Squirtle(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        Wartortle evo1 = new Wartortle("Wartortle", (byte) (nivel + 5), hp * 2);
        return evo1;
    }

    @Override
    public String gritar() {
        return "Squirtle!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
