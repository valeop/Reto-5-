package Reto5;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.Random;

public abstract class Pokemon {

    private static Random aleatorio = new Random();
    static String[] botones1 = {"Buscar pokemón", "Lista de pokemones", "Salir"};
    static String[] botones2 = {"Crear pokebola y guardar pokemón\n", "Evolucionar", "¡Grito!", "Cancelar"};
    static String[] botones3 = {"Grande", "Mediana", "Pequeña"};
    public static List<Object> lista = new ArrayList<Object>();
    private static byte nivel;
    private static int hp, numero, choice, choice2 = 1, choice3;
    private static String nombre, tamanio;
    private static Pokemon pokemon;
    static Pokebola poke = null;
//-------------------- Instancia y declaración de astributos y objetos necesarios ------------------

    public abstract Pokemon evolucionar();

    public abstract String gritar();

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public abstract byte getNivel();

    public abstract int getHp();

    public abstract String getNombre();

    public void excepcion() {
        try {
            throw new EvolucionException("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "El pokemón alcanzó su máxima evolución", "INFORMACIÓN", JOptionPane.INFORMATION_MESSAGE);
        }
    }
//----------------------- Creación de métodos abstractos, sobreescritos, Getters y excepción ------------------------
//----------------------- Creación de otros métodos para diversas operaciones  y método main ------------------------

    public static String asignarNombre(int eleccion) {
        String nombre = "";
        switch (eleccion) {
            case 1:
                nombre = "Charmander";
                break;
            case 2:
                nombre = "Charmeleon";
                break;
            case 3:
                nombre = "Charizard";
                break;
            case 4:
                nombre = "Squirtle";
                break;
            case 5:
                nombre = "Wartortle";
                break;
            case 6:
                nombre = "Blastoise";
                break;
            case 7:
                nombre = "Pikachu";
                break;
            case 8:
                nombre = "Raichu";
                break;
        }
        return nombre;
    }

    private static void asignarTamanio(int eleccion) {
        switch (eleccion) {
            case 0:
                tamanio = "Grande";
                break;
            case 1:
                tamanio = "Mediana";
                break;
            case 2:
                tamanio = "Pequeña";
                break;
        }
    }

    private static Pokemon crearPokemon(String pokemon, int eleccion) {
        Pokemon objeto = null;
        switch (pokemon) {
            case "Charmander":
                objeto = new Charmander(nombre, nivel, hp);
                break;
            case "Charmeleon":
                objeto = new Charmeleon(nombre, nivel, hp);
                break;
            case "Charizard":
                objeto = new Charizard(nombre, nivel, hp);
                break;
            case "Squirtle":
                objeto = new Squirtle(nombre, nivel, hp);
                break;
            case "Wartortle":
                objeto = new Wartortle(nombre, nivel, hp);
                break;
            case "Blastoise":

                objeto = new Blastoise(nombre, nivel, hp);
                break;
            case "Pikachu":
                objeto = new Pikachu(nombre, nivel, hp);
                break;
            case "Raichu":
                objeto = new Raichu(nombre, nivel, hp);
                break;
        }
        switch (eleccion) {
            case 0:
                poke = new Pokebola(tamanio, objeto);
                lista.add(poke.guardarPokemon());
                break;
            case 1:
                objeto = objeto.evolucionar();
                break;
            case 2:
                JOptionPane.showMessageDialog(null, objeto.gritar(), "GRITO", JOptionPane.INFORMATION_MESSAGE);
                break;

        }
        return objeto;
    }

    public static void main(String[] args) {
        while (choice != 2) {
            choice = JOptionPane.showOptionDialog(null, "Selecciona la opción que deseas", "BIENVENIDO", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, botones1, botones1[0]);
            if (choice == 0) {
                nivel = (byte) (aleatorio.nextInt(99) + 1);
                hp = (nivel + aleatorio.nextInt(5) + 3) * 10;
                numero = aleatorio.nextInt(7) + 1;
                nombre = asignarNombre(numero);
                choice2 = 1;
                while (choice2 == 1 || choice2 == 2) {
                    choice2 = JOptionPane.showOptionDialog(null, "Nombre: " + nombre + "\nNivel: " + nivel + "\nHP: " + hp, "DATOS DEL POKEMÓN", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, botones2, botones2[0]);
                    if (choice2 == 0) {
                        choice3 = JOptionPane.showOptionDialog(null, "Selecciona el tamanio de la pokebola", "TAMAÑO POKEBOLA", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, botones3, botones3[0]);
                        if (choice3 == 0 || choice3 == 1 || choice3 == 2) {
                            asignarTamanio(choice3);
                            pokemon = crearPokemon(nombre, choice2);
                            JOptionPane.showMessageDialog(null, "Se ha guardado " + nombre + " con éxito.", "ATENCIÓN", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    if (choice2 == 1 || choice2 == 2) {
                        pokemon = crearPokemon(nombre, choice2);
                        nombre = pokemon.getNombre();
                        nivel = pokemon.getNivel();
                        hp = pokemon.getHp();
                    }
                    if (choice2 == 3) {
                        choice = 1;
                        choice2 = 3;
                    }
                }
            } else if (choice == 1) {
                poke = new Pokebola();
                if (lista.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "La lista está vacía", "INFORMACIÓN", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    poke.mostrarLista();
                }
            } else if (choice == 2) {
                System.exit(0);
            }

        }
    }

}
