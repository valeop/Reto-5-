package Reto5;

public class Pikachu extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Pikachu(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        Raichu evo1 = new Raichu("Raichu", (byte) (nivel + 12), hp * 4);
        return evo1;
    }

    @Override
    public String gritar() {
        return "Pikachu!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
