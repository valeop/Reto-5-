package Reto5;

public class Charmeleon extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Charmeleon(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        Charizard evo2 = new Charizard("Charizard", (byte) (nivel + 7), hp);
        return evo2;
    }

    @Override
    public String gritar() {
        return "Charmeleon!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
