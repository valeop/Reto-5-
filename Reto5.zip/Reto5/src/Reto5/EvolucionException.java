package Reto5;

public class EvolucionException extends Exception {

    public EvolucionException(String mensaje) {
        super(mensaje);
    }
}
