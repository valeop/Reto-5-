package Reto5;

public class Wartortle extends Pokemon {

    private String nombre;
    private byte nivel;
    private int hp;

    public Wartortle(String nombre, byte nivel, int hp) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.hp = hp;
    }

    @Override
    public Pokemon evolucionar() {
        Blastoise evo2 = new Blastoise("Blastoise", (byte) (nivel + 7), hp * 2);
        return evo2;
    }

    @Override
    public String gritar() {
        return "Wartortle!";
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel + " | Hp: " + hp;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getNivel() {
        return nivel;
    }

    public int getHp() {
        return hp;
    }

}
